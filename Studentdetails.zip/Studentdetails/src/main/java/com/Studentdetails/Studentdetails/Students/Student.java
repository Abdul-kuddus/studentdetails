package com.Studentdetails.Studentdetails.Students;
import java.util.*;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
private int Id;

private String name;
private String dob;

private String[] date = dob.split("/");

private int day = Integer.parseInt(date[0]);
private int Month = Integer.parseInt(date[1]);
private int year = Integer.parseInt(date[2]);

private int age = Age.agecal(year);

public Student(){}

public Student(String name, String dob)
{
this.name = name;
this.dob = dob;
}

public int getId() {
    return Id;
}

public String getName() {
    return name;
}

public String getDob() {
    return dob;
}

public String[] getDate() {
    return date;
}

public int getDay() {
    return day;
}

public int getMonth() {
    return Month;
}

public int getYear() {
    return year;
}

public int getAge() {
    return age;
}

public void setId(int id) {
    Id = id;
}

public void setName(String name) {
    this.name = name;
}

public void setDob(String dob) {
    this.dob = dob;
}

public void setDate(String[] date) {
    this.date = date;
}

public void setDay(int day) {
    this.day = day;
}

public void setMonth(int month) {
    Month = month;
}

public void setYear(int year) {
    this.year = year;
}

public void setAge(int age) {
    this.age = age;
}

public String toString()
{return(this.getId() + this.getDob() + this.getDay() + this.getMonth() + this.getYear() + this.getAge());}

}

