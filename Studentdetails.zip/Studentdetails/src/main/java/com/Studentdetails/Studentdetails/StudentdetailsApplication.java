package com.Studentdetails.Studentdetails;
import com.Studentdetails.Studentdetails.Students.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentdetailsApplication implements CommandLineRunner{

	@Autowired
	Student student;

	public static void main(String[] args) {
		SpringApplication.run(StudentdetailsApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception{

		Student student = new Student("abdul","19/08/1993");
student.toString();
	}

}
