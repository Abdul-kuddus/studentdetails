package com.Studentdetails.Studentdetails.Students;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface StudentRepository extends JpaRepository<Student,Integer> {
@Query("select s from Student s where s.age between 18 and 25")    
List<Student> find_by_age(int age);

}
