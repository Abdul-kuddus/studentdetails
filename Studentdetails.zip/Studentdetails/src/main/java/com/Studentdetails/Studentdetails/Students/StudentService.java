package com.Studentdetails.Studentdetails.Students;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class StudentService {

@Autowired
StudentRepository studentRepository;   

public void createStudent(Student student){
studentRepository.save(student);}

public List<Student> getStudent(int age)
{
    return studentRepository.find_by_age(age);
}
}
