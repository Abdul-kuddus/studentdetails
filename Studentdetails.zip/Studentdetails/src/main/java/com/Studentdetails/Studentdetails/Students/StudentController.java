package com.Studentdetails.Studentdetails.Students;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.util.*;


@RestController
public class StudentController {

    @Autowired
    StudentService studentService;

    @PostMapping("/createStudent")
    public ResponseEntity createStudent(@RequestBody Student student)
    {studentService.createStudent(student);
        return new ResponseEntity("Student added to the system", HttpStatus.ACCEPTED);
    }

    @GetMapping("/getStudent")
    public ResponseEntity find_by_age(@RequestParam(value = "genre",required = false) int age)
    {
        List<Student> studentlist = studentService.getStudent(age);
        return new ResponseEntity(studentlist,HttpStatus.OK);
    }

}
