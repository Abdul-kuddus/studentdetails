package com.Studentdetails.Studentdetails.Students;
import java.util.*;
public class Age {

    public static int agecal(int birthyear)
    {
        int age;
        int currentyear = Calendar.getInstance().get(Calendar.YEAR);
        age = currentyear - birthyear;
        return age;

    }

}
