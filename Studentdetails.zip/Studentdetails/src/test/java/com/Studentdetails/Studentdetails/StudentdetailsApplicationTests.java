package com.Studentdetails.Studentdetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentdetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
